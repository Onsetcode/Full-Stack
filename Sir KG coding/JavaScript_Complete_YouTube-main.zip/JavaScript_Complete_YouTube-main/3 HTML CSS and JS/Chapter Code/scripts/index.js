/* console.log('I am coming from index.js')
 This method is used to clear the console */
console.clear()